export interface VisibleLabelLine {
    text: string;
    baseline: number;
}
export interface LabelInkMeasurement {
    top: number;
    bottom: number;
    height: number;
    offsetY: number;
}
export declare function normalizeLabelVAlign(value: unknown): 'top' | 'middle' | 'optical-middle' | 'bottom';
/**
 * Measure the ink in the laid-out label, in CSS pixels relative to its box.
 * Supply the displayed text of each line (including any ellipsis), its
 * alphabetic baseline, and a canvas context configured with the label's font
 * and text settings. A positive offset moves the entire text block down.
 * Returns null for empty ink or unavailable metrics.
 */
export declare function measureLabelInk(context: Pick<CanvasRenderingContext2D, 'measureText'>, lines: readonly VisibleLabelLine[], boxHeight: number): LabelInkMeasurement | null;
/** Read the browser's line breaks without moving or changing the live label. */
export declare function measureRenderedLabelInk(host: HTMLElement, text: HTMLElement, maxLines: number, boxHeight: number, hostTop: number): LabelInkMeasurement | null;
