"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/renderer/core.ts
var core_exports = {};
__export(core_exports, {
  ELEMENT_ANCHOR_PROPERTY_TYPES: () => ELEMENT_ANCHOR_PROPERTY_TYPES,
  localizeDialogDocument: () => localizeDialogDocument,
  planElementAnchors: () => planElementAnchors,
  readElementAnchor: () => readElementAnchor,
  resolveElementAnchorPosition: () => resolveElementAnchorPosition,
  validateElementAnchor: () => validateElementAnchor
});
module.exports = __toCommonJS(core_exports);

// src/core/layout/elementAnchoring.ts
var ELEMENT_ANCHOR_PROPERTY_TYPES = {
  anchorTarget: "string",
  anchorPosition: "string",
  anchorGap: "number",
  anchorAlign: "string",
  anchorOffset: "number"
};
function readElementAnchorDistance(value, property, fallback) {
  if (value === void 0) {
    return fallback;
  }
  if (typeof value !== "number" && (typeof value !== "string" || value.trim() === "")) {
    throw new Error(`Element anchor ${property} must be a finite number.`);
  }
  const distance = Number(value);
  if (!Number.isFinite(distance)) {
    throw new Error(`Element anchor ${property} must be a finite number.`);
  }
  return distance;
}
function readElementAnchor(record) {
  if (record.anchorTarget === void 0 || record.anchorTarget === "") {
    return null;
  }
  if (typeof record.anchorTarget !== "string") {
    throw new Error("Element anchor target must be an element id.");
  }
  const target = record.anchorTarget.trim();
  if (!target) {
    return null;
  }
  const requestedPosition = record.anchorPosition === void 0 ? "left" : record.anchorPosition;
  if (typeof requestedPosition !== "string") {
    throw new Error("Element anchor position must be left, right, above, or below.");
  }
  const position = requestedPosition.trim().toLowerCase();
  if (position !== "left" && position !== "right" && position !== "above" && position !== "below") {
    throw new Error("Element anchor position must be left, right, above, or below.");
  }
  const requestedAlignment = record.anchorAlign === void 0 ? "middle" : record.anchorAlign;
  if (typeof requestedAlignment !== "string") {
    throw new Error("Element anchor alignment must be start, middle, or end.");
  }
  const align = requestedAlignment.trim().toLowerCase();
  if (align !== "start" && align !== "middle" && align !== "end") {
    throw new Error("Element anchor alignment must be start, middle, or end.");
  }
  return {
    target,
    position,
    gap: readElementAnchorDistance(record.anchorGap, "gap", 10),
    align,
    offset: readElementAnchorDistance(record.anchorOffset, "offset", 0)
  };
}
function elementAnchorName(element) {
  return element.name?.trim() || element.id;
}
function readPlannedElementAnchor(anchor) {
  if (!anchor || typeof anchor !== "object" || Array.isArray(anchor)) {
    throw new Error("Element anchor metadata must describe an attachment.");
  }
  const parsed = readElementAnchor({
    anchorTarget: anchor.target,
    anchorPosition: anchor.position,
    anchorGap: anchor.gap,
    anchorAlign: anchor.align,
    anchorOffset: anchor.offset
  });
  if (!parsed) {
    throw new Error("Element anchor target must be an element id.");
  }
  return parsed;
}
function validateElementAnchorRelationship(element, anchor, elements) {
  if (!element.id.trim()) {
    throw new Error("An attached element must have an id.");
  }
  const sourceType = element.type.trim().toLowerCase();
  if (!sourceType || sourceType === "group") {
    throw new Error("Only non-group elements can use relative positioning.");
  }
  if (element.id === anchor.target) {
    const name = elementAnchorName(element);
    throw new Error(`Attachment cycle: ${name} \u2192 ${name}. An element cannot be attached to itself.`);
  }
  const target = elements.find((element2) => element2.id === anchor.target);
  if (!target) {
    throw new Error(`Element anchor target "${anchor.target}" was not found.`);
  }
  const targetType = target.type.trim().toLowerCase();
  if (!targetType || targetType === "group") {
    throw new Error("Element anchor targets must be non-group elements.");
  }
  const elementParent = (element.parentId || "").trim();
  const targetParent = (target.parentId || "").trim();
  if (elementParent !== targetParent) {
    throw new Error("The element and its anchor target must be in the same group or both on the canvas.");
  }
}
function planElementAnchors(elements) {
  const byId = /* @__PURE__ */ new Map();
  const anchors = /* @__PURE__ */ new Map();
  const errors = /* @__PURE__ */ new Map();
  const states = /* @__PURE__ */ new Map();
  const path = [];
  const order = [];
  for (const element of elements) {
    if (byId.has(element.id)) {
      errors.set(element.id, `Element id "${element.id}" is not unique.`);
    } else {
      byId.set(element.id, element);
    }
    if (element.anchorError?.trim()) {
      errors.set(element.id, element.anchorError);
    }
  }
  for (const element of byId.values()) {
    if (element.anchor === void 0 || element.anchor === null) {
      continue;
    }
    try {
      const anchor = readPlannedElementAnchor(element.anchor);
      anchors.set(element.id, anchor);
      validateElementAnchorRelationship(element, anchor, elements);
    } catch (error) {
      if (!errors.has(element.id)) {
        errors.set(element.id, error instanceof Error ? error.message : String(error));
      }
    }
  }
  function visit(id) {
    const state = states.get(id);
    if (state === "complete") {
      return !errors.has(id);
    }
    if (state === "visiting") {
      const cycle = path.slice(path.indexOf(id));
      const names = [...cycle, id].map((member) => elementAnchorName(byId.get(member)));
      const message = `Attachment cycle: ${names.join(" \u2192 ")}.`;
      for (const member of cycle) {
        errors.set(member, message);
      }
      return false;
    }
    states.set(id, "visiting");
    path.push(id);
    const anchor = anchors.get(id);
    if (!errors.has(id) && anchor && !visit(anchor.target)) {
      if (!errors.has(id)) {
        const target = byId.get(anchor.target);
        errors.set(id, `Cannot attach to "${elementAnchorName(target)}": its attachment is invalid.`);
      }
    }
    path.pop();
    states.set(id, "complete");
    if (errors.has(id)) {
      return false;
    }
    if (anchor) {
      order.push(id);
    }
    return true;
  }
  for (const id of byId.keys()) {
    visit(id);
  }
  const issues = Array.from(errors, ([elementId, message]) => ({ elementId, message }));
  return { order, issues };
}
function validateElementAnchor(element, anchor, elements) {
  const proposed = readPlannedElementAnchor(anchor);
  validateElementAnchorRelationship(element, proposed, elements);
  const replacement = { ...element, anchor: proposed, anchorError: void 0 };
  let found = false;
  const graph = elements.map((candidate) => {
    if (candidate.id !== element.id) {
      return candidate;
    }
    found = true;
    return replacement;
  });
  if (!found) {
    graph.push(replacement);
  }
  const issue = planElementAnchors(graph).issues.find((candidate) => candidate.elementId === element.id);
  if (issue) {
    throw new Error(issue.message);
  }
}
function validateElementAnchorRect(rect, name) {
  if (![rect.left, rect.top, rect.width, rect.height].every(Number.isFinite) || rect.width < 0 || rect.height < 0) {
    throw new Error(`${name} bounds must be finite, with non-negative width and height.`);
  }
}
function resolveElementAnchorPosition(element, target, anchor) {
  validateElementAnchorRect(element, "Element");
  validateElementAnchorRect(target, "Anchor target");
  if (!Number.isFinite(anchor.gap) || !Number.isFinite(anchor.offset)) {
    throw new Error("Element anchor gap and offset must be finite numbers.");
  }
  let fraction = 0;
  if (anchor.align === "middle") {
    fraction = 0.5;
  } else if (anchor.align === "end") {
    fraction = 1;
  } else if (anchor.align !== "start") {
    throw new Error("Element anchor alignment must be start, middle, or end.");
  }
  let left;
  let top;
  if (anchor.position === "left" || anchor.position === "right") {
    left = anchor.position === "left" ? target.left - anchor.gap - element.width : target.left + target.width + anchor.gap;
    top = target.top + (target.height - element.height) * fraction + anchor.offset;
  } else if (anchor.position === "above" || anchor.position === "below") {
    left = target.left + (target.width - element.width) * fraction + anchor.offset;
    top = anchor.position === "above" ? target.top - anchor.gap - element.height : target.top + target.height + anchor.gap;
  } else {
    throw new Error("Element anchor position must be left, right, above, or below.");
  }
  if (!Number.isFinite(left) || !Number.isFinite(top)) {
    throw new Error("The resolved element anchor position must be finite.");
  }
  return { left, top };
}

// src/renderer/documentLocalization.ts
var clonePreviewDialog = (input) => {
  try {
    return JSON.parse(JSON.stringify(input));
  } catch {
    return input;
  }
};
var resolveTranslation = (baseDict, localeDict, element, prop) => {
  const ids = [
    String(element.id ?? "").trim()
  ].filter(Boolean);
  for (const id of ids) {
    const key = `elements.${id}.${prop}`;
    if (localeDict[key] !== void 0) return localeDict[key];
    if (baseDict[key] !== void 0) return baseDict[key];
  }
  return void 0;
};
var translateDelimitedItems = (baseDict, localeDict, element, raw) => {
  const ids = [
    String(element.id ?? "").trim()
  ].filter(Boolean);
  const values = String(raw ?? "").split(/[;,]/).map((item) => item.trim());
  if (!ids.length || !values.some(Boolean)) {
    return void 0;
  }
  let changed = false;
  const translated = values.map((value, index) => {
    for (const id of ids) {
      const key = `elements.${id}.items.${index}`;
      if (localeDict[key] !== void 0) {
        changed = true;
        return localeDict[key];
      }
      if (baseDict[key] !== void 0) {
        changed = true;
        return baseDict[key];
      }
    }
    return value;
  });
  return changed ? translated.join(", ") : void 0;
};
var localizeDialogDocument = (input, locale) => {
  const copy = clonePreviewDialog(input);
  const i18n = copy.i18n;
  if (!i18n?.locales) {
    return copy;
  }
  const baseLocale = String(i18n.baseLocale || copy.properties.language || "").trim();
  const baseDict = baseLocale && i18n.locales[baseLocale] || {};
  const localeDict = i18n.locales[locale] || baseDict;
  copy.properties.language = locale;
  const title = localeDict["dialog.title"] ?? baseDict["dialog.title"];
  if (title !== void 0) {
    copy.properties.title = title;
  }
  copy.elements = copy.elements.map((element) => {
    const next = { ...element };
    const type = String(next.type || "").trim();
    const label = resolveTranslation(baseDict, localeDict, next, "label");
    if (label !== void 0) {
      next.label = label;
    }
    const value = resolveTranslation(baseDict, localeDict, next, "value");
    if (value !== void 0) {
      if (type === "Select") {
        next.__localizedValue = value;
      } else {
        if (type === "Label") {
          next.__baseValue ??= next.value;
        }
        next.value = value;
      }
    }
    const itemText = translateDelimitedItems(baseDict, localeDict, next, next.items);
    if (itemText !== void 0) {
      if (type === "Choice") {
        const values = String(next.items || "").split(",").map((value2) => value2.trim());
        const labels = itemText.split(",").map((value2) => value2.trim());
        next.__itemLabels = Object.fromEntries(values.map((value2, index) => [value2, labels[index] || value2]));
      } else {
        next.items = itemText;
      }
    }
    if (type === "Choice" && itemText === void 0) {
      const choiceValue = resolveTranslation(baseDict, localeDict, next, "items");
      if (choiceValue !== void 0) {
        next.items = choiceValue;
      }
    }
    return next;
  });
  return copy;
};
