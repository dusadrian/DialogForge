import { Datasets } from "../interfaces/datasets";
export declare const datasets: Datasets;
