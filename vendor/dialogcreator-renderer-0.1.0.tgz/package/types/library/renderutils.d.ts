import { RenderUtils } from '../interfaces/renderutils';
export declare const errorutils: {
    addTooltip(element: string | string[], message: string): void;
    clearTooltip(element: string | string[], message?: string): void;
    addHighlight(element: string | string[], kind?: "field" | "radio"): void;
    clearHighlight(element: string | string[]): void;
};
export declare const errorhelpers: {
    addTooltip(element: string | string[], message: string): void;
    clearTooltip(element: string | string[], message?: string): void;
    addHighlight(element: string | string[], kind?: "field" | "radio"): void;
    clearHighlight(element: string | string[]): void;
};
export declare const renderutils: RenderUtils;
