import type { PreviewUI, PreviewUIEnv } from '../interfaces/preview';
export declare const EVENT_LIST: readonly ["click", "change", "input"];
export type EventName = typeof EVENT_LIST[number];
export declare const EVENT_NAMES: Set<string>;
export declare const API_NAMES: ReadonlyArray<keyof PreviewUI>;
export declare const ELEMENT_FIRST_ARG_CALLS: ReadonlyArray<keyof PreviewUI>;
export declare function createPreviewUI(env: PreviewUIEnv): PreviewUI;
