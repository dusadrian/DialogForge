export interface ElementAnchorIssue {
    elementId: string;
    message: string;
}
export declare function hasElementAnchor(element: HTMLElement): boolean;
export declare function getElementAnchorError(element: HTMLElement): string;
export declare function refreshElementAnchors(canvas: HTMLElement): ElementAnchorIssue[];
export declare function requestElementAnchorLayout(element: HTMLElement): void;
export declare function setElementAnchorProperties(element: HTMLElement, properties: Readonly<Record<string, string | number | undefined>>): void;
export declare function canElementAnchorTo(element: HTMLElement, target: HTMLElement): string;
export declare function followsSelectedAnchor(element: HTMLElement, selectedIds: ReadonlySet<string>): boolean;
export declare function moveAnchoredElement(element: HTMLElement, left: number, top: number): boolean;
export declare function installElementAnchors(canvas: HTMLElement, options?: {
    updateLabel?: (label: HTMLElement) => void;
}): () => void;
