import { Utils } from '../interfaces/utils';
export declare const utils: Utils;
