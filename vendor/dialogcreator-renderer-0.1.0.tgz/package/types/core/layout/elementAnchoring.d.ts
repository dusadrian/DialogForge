export type ElementAnchorSide = 'left' | 'right' | 'above' | 'below';
export type ElementAnchorAlignment = 'start' | 'middle' | 'end';
export type ElementAnchorProperties = {
    anchorTarget?: string;
    anchorPosition?: ElementAnchorSide;
    anchorGap?: number;
    anchorAlign?: ElementAnchorAlignment;
    anchorOffset?: number;
};
export declare const ELEMENT_ANCHOR_PROPERTY_TYPES: {
    readonly anchorTarget: "string";
    readonly anchorPosition: "string";
    readonly anchorGap: "number";
    readonly anchorAlign: "string";
    readonly anchorOffset: "number";
};
export interface ElementAnchor {
    target: string;
    position: ElementAnchorSide;
    gap: number;
    align: ElementAnchorAlignment;
    offset: number;
}
export interface ElementAnchorElement {
    id: string;
    type: string;
    parentId?: string;
    name?: string;
    anchor?: ElementAnchor | null;
    anchorError?: string;
}
export interface ElementAnchorIssue {
    elementId: string;
    message: string;
}
export interface ElementAnchorPlan {
    order: string[];
    issues: ElementAnchorIssue[];
}
export interface ElementAnchorPosition {
    left: number;
    top: number;
}
export interface ElementAnchorRect extends ElementAnchorPosition {
    width: number;
    height: number;
}
export declare function readElementAnchor(record: Readonly<Record<string, unknown>>): ElementAnchor | null;
export declare function planElementAnchors(elements: readonly ElementAnchorElement[]): ElementAnchorPlan;
export declare function validateElementAnchor(element: ElementAnchorElement, anchor: ElementAnchor, elements: readonly ElementAnchorElement[]): void;
export declare function resolveElementAnchorPosition(element: ElementAnchorRect, target: ElementAnchorRect, anchor: ElementAnchor): ElementAnchorPosition;
