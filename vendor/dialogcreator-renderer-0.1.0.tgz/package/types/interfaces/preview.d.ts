import type { Dialog, DialogI18n } from './dialog';
import { StringNumber } from './elements';
export interface ContainerItemDescriptor {
    name: string;
    numeric?: boolean;
    factor?: boolean;
    calibrated?: boolean;
    binary?: boolean;
    character?: boolean;
    categorical?: boolean;
    date?: boolean;
    active?: boolean;
    enabled?: boolean;
}
export type ObjectBindingVariables = string | string[] | Record<string, string | string[]>;
export interface ObjectBindingRequest {
    dialog?: string;
    datasets: string;
    variables?: ObjectBindingVariables;
    autoSelect?: boolean;
    excludeSelected?: string;
}
/**
 * Handle returned by bindObjects(). Declaring a binding is synchronous; only
 * the data refresh is asynchronous. Dialogs keep the handle and call refresh()
 * when they reset.
 */
export interface ObjectBinding {
    refresh(): Promise<void>;
}
/**
 * One piece of a generated command. Arrays are flattened, and parts that carry
 * nothing are dropped, so optional arguments can be collected unconditionally.
 */
export type SyntaxPart = string | number | null | undefined | Array<string | number | null | undefined>;
export interface PreviewUI {
    /** Log helper (forwards to editor console) */
    log(...args: unknown[]): void;
    /** Show an app message dialog */
    showMessage(message: string, detail?: string, type?: 'info' | 'error' | 'question' | 'warning'): void;
    showMessage(type: 'info' | 'error' | 'question' | 'warning', title: string, message: string): void;
    showMessage(type: 'info' | 'error' | 'question' | 'warning', message: string): void;
    /** Legacy stub retained for compatibility. Does nothing in Preview. */
    run(command: string): void;
    /**
     * Call an app-specific external function.
     * In Dialog Creator Preview this is a no-op; target apps may override it.
     */
    callExternal(name: string, parameters?: unknown): Promise<unknown>;
    /** Update the syntax panel with the provided command. */
    updateSyntax(command: string): void;
    /** Reset the dialog to its initial Preview state (as first opened). */
    resetDialog(): void;
    /**
     * Request that the dialog be closed.
     * In Dialog Creator Preview this closes only the Preview window;
     * target apps may interpret it as a host-app close signal.
     */
    closeDialog(): void;
    /** Generic getter (value / dataset-driven) */
    get(element: string, prop: string): unknown;
    /** Generic setter */
    set(element: string, prop: string, value: unknown): void;
    /** Unified getters/setters */
    getValue(element: string): unknown;
    setValue(element: string, value: unknown | string[] | ContainerItemDescriptor[]): void;
    getSelected(element: string): string[] | '';
    /** Checkbox/Radio convenience for checked/selected */
    isChecked(element: string): boolean;
    isUnchecked(element: string): boolean;
    /** Checkbox/Radio convenience: set checked/selected state to true */
    check(element: string): void;
    check(...elements: string[]): void;
    /** Checkbox/Radio convenience: set checked/selected state to false */
    uncheck(element: string): void;
    uncheck(...elements: string[]): void;
    /** Returns whether the element is currently visible in Preview */
    isVisible(element: string): boolean;
    isHidden(element: string): boolean;
    /** Returns whether the element is currently enabled (interactive) in Preview */
    isEnabled(element: string): boolean;
    isDisabled(element: string): boolean;
    /** Show / hide */
    show(element: string, on?: boolean): void;
    hide(element: string, on?: boolean): void;
    /** Enable / disable */
    enable(element: string, on?: boolean): void;
    disable(element: string, on?: boolean): void;
    /** Error helpers */
    addError(element: string, message: string): void;
    clearError(element: string, message?: string): void;
    clearError(...elements: string[]): void;
    /** Return list of available objects for the requested workspace type */
    listObjects(type: string): string[];
    /** Return list of columns specific to a dataset */
    listColumns(dataset: string | string[]): Array<string | ContainerItemDescriptor>;
    /** Bind object and field controls to the host data environment. */
    bindObjects(request: ObjectBindingRequest): ObjectBinding;
    /**
     * The object selected in the given control, written the way the generated
     * command should refer to it. Normally the plain object name, but a host
     * may return an expression when the object is filtered or otherwise
     * derived. Returns an empty string when nothing is selected.
     */
    getReference(element: string): string;
    /**
     * Build a call rendered with one argument per line. Multi-line arguments
     * are re-indented to their nesting depth, so nested calls and blocks lay
     * themselves out without the script counting spaces.
     */
    call(name: string, ...args: SyntaxPart[]): string;
    /** Build a brace-delimited block of statements, indented one level. */
    block(...statements: SyntaxPart[]): string;
    /** Shift every line of the text right by the given number of levels (default 1). */
    indent(text: string, levels?: number): string;
    /** Register an event handler on the wrapper */
    on(element: string, event: string, handler: (ev: Event, el: HTMLElement) => void): void;
    /** Convenience: onClick/onChange/onInput wrappers */
    onClick(element: string, handler: (ev: Event, el: HTMLElement) => void): void;
    onChange(element: string, handler: (ev: Event, el: HTMLElement) => void): void;
    onInput(element: string, handler: (ev: Event, el: HTMLElement) => void): void;
    /** Dispatch an event on the element (bubbling), without changing state. Supported: 'click', 'change', 'input'. Defaults to 'change'. */
    trigger(element: string, event?: 'click' | 'change' | 'input'): void;
    /** Convenience: trigger a 'change' event on the element. */
    triggerChange(element: string): void;
    /** Convenience: trigger a 'click' event on the element. */
    triggerClick(element: string): void;
    /** Make an Input behave like a live search box for one or more Container elements. */
    searchIn(input: string, ...containers: string[]): void;
    /** Enable transient Cmd/Ctrl+F search for specific Container elements. */
    enableSearch(...containers: string[]): void;
    /** Set selection: Select elements (single value) or Container/Choice items (accepts string or string[]). */
    setSelected(element: string, value: string | string[]): void;
    /** Legacy alias (additive for Container). Prefer setSelected for explicit selection. */
    select(element: string, value: string): void;
    /** Add a new item to a Container (does nothing for Select). */
    addValue(element: string, value: string | ContainerItemDescriptor): void;
    /** Clear item(s) from a Container by their label(s) (does nothing for Select). */
    clearValue(element: string, value: string | string[]): void;
    /** Clear the value of an Input element. */
    clearInput(element: string): void;
    /** Clear content of supported elements (Input, Container). */
    clearContent(...elements: string[]): void;
    /** Set the visible label text of a Button element. */
    setLabel(element: string, label: string): void;
    /** Change the label of a specific item within a Container. */
    changeValue(element: string, oldValue: string, newValue: string): void;
    /**
     * Call a backend service by name. Returns a Promise, and also supports an optional callback for simplicity.
     * If a callback is provided, it will be called with the result when available.
     */
    /** Dispose all registered event handlers (internal use) */
    __disposeAll(): void;
}
export interface PreviewUIEnv {
    findWrapper: (element: string) => HTMLElement | null;
    findRadioGroupMembers: (group: string) => HTMLElement[];
    updateElement: (element: HTMLElement, props: StringNumber) => void;
    showRuntimeError: (msg: string) => void;
    logToEditor: (msg: string) => void;
    showDialogMessage: (type: 'info' | 'warning' | 'error' | 'question', message: string, detail: string) => void;
    callExternal?: (name: string, parameters?: unknown) => Promise<unknown>;
    bindObjects?: (request: ObjectBindingRequest) => unknown;
    resolveReference?: (element: string, selected: string) => string;
    translateMessage?: (text: string) => string;
    openSyntaxPanel?: (command: string) => void;
    resetDialog: () => void;
    closeDialog?: () => void | Promise<void>;
}
export interface PreviewScriptExports {
    /** Optional initialization hook; called after user script loads */
    init?: (ui: PreviewUI) => void;
    /** Optional disposer hook; called before preview re-renders or unloads */
    dispose?: (ui: PreviewUI) => void;
    /** Allow additional properties (user-defined state) while keeping known hooks typed */
    [key: string]: unknown;
}
export interface PreviewDialog {
    id: string;
    properties: {
        name?: string | number;
        title?: string | number;
        language?: string | number;
        runtimeProvider?: string | number;
        width: string | number;
        height: string | number;
        background?: string;
        fontSize?: string | number;
    };
    syntax: Dialog['syntax'];
    elements: Array<Record<string, any>>;
    i18n?: DialogI18n;
    customJS?: string;
}
