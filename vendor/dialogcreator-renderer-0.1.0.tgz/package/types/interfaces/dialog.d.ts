export type DialogLocaleDictionary = Record<string, string>;
export interface DialogI18n {
    baseLocale: string;
    locales: Record<string, DialogLocaleDictionary>;
}
export interface DialogProperties {
    name: string;
    title: string;
    language: string;
    runtimeProvider?: string;
    /**
     * Packages the dialog needs from its runtime provider, comma or semicolon
     * separated. Travels inside the package so a target app can pick the
     * requirement up on import.
     */
    dependencies?: string;
    width: string;
    height: string;
    fontSize: string;
    background?: string;
}
export interface Dialog {
    canvas: HTMLDivElement;
    id: string;
    selectedElement: string;
    properties: DialogProperties;
    elements: {
        [key: string]: HTMLElement;
    };
    syntax: {
        command: string;
        defaultElements: [];
    };
    i18n?: DialogI18n;
    customJS: string;
    initialize: (obj: DialogProperties) => void;
    updateElementProperties: (id: string, payload: {
        [key: string]: string;
    }) => void;
    addElement: (element: HTMLElement) => void;
    removeElement: (elId: string) => void;
    getElement: (elId: string) => HTMLElement | undefined;
}
