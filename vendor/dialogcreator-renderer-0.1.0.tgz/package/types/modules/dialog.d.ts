import { Dialog } from '../interfaces/dialog';
export declare const dialog: Dialog;
