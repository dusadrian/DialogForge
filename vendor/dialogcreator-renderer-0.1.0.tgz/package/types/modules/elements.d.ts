import { Elements } from '../interfaces/elements';
type ElementEntryWithPersist<T> = T & {
    $persist?: readonly (keyof T)[];
};
export type ElementsWithPersist = {
    [K in keyof Elements]: ElementEntryWithPersist<Elements[K]>;
};
export declare const elements: ElementsWithPersist;
export {};
