export declare const rendererEnvironment: {
    fontSize: number;
    fontFamily: string;
    log: (message: string) => void;
    reportError: (message: string) => void;
};
