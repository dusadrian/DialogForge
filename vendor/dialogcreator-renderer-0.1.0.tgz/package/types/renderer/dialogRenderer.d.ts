import type { PreviewDialog, PreviewUI, PreviewUIEnv } from '../interfaces/preview';
export interface DialogRendererHost {
    log(message: string): void;
    showMessage: PreviewUIEnv['showDialogMessage'];
    closeDialog?: PreviewUIEnv['closeDialog'];
    callExternal?: PreviewUIEnv['callExternal'];
    bindObjects?: PreviewUIEnv['bindObjects'];
    resolveReference?: PreviewUIEnv['resolveReference'];
    openSyntaxPanel?: PreviewUIEnv['openSyntaxPanel'];
    setTitle?: (title: string) => void;
}
export interface DialogRendererOptions {
    languageSwitcher?: boolean;
    executeActions?: boolean;
    controls?: Record<string, (data: Readonly<Record<string, unknown>>) => HTMLElement>;
}
export declare function createDialogRenderer(root: HTMLElement, host: DialogRendererHost, options?: DialogRendererOptions): {
    render(data: PreviewDialog, locale?: string): void;
    readonly ui: PreviewUI;
    readonly canvas: HTMLElement;
    dispose(): void;
};
