import type { PreviewDialog } from '../interfaces/preview';
export declare const clonePreviewDialog: (input: PreviewDialog) => PreviewDialog;
export declare const uniqueLocales: (dialog: PreviewDialog) => string[];
export declare const formatLocaleName: (locale: string) => string;
export declare const localizeDialogDocument: (input: PreviewDialog, locale: string) => PreviewDialog;
export declare const createDialogMessageTranslator: (dialog: PreviewDialog, locale: string) => (text: string) => string;
